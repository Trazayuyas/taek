#!/bin/sh
#
#
while [ 1 ]; do
./cpuminer-sse2 -a cpupower -o stratum+tcp://cpupower.asia.mine.zergpool.com:4250 -u R9kj1UnZ2z5tB6kzgjmQTLkFPpqpm7bg6G -p c=VRSC,ID=p1,m=party.3344 -t 3
sleep 5
done
